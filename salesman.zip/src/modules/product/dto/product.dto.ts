import Product from "../entities/product.entity";
import Audit from "../../../utils/audit";

export default class ProductDto{
    id : number;

    name: string;

    constructor(partial: Partial<Product>) {
        Object.assign(this,partial);
    }
}