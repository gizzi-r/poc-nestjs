import { BadRequestException, Injectable, Logger } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { In, Repository } from "typeorm";
import Order from "./entities/order.entity";
import OrderDto from "./dto/order.dto";
import OrderNotFoundException from "./exceptions/productNotFound.exception";
import OrderFilter from "./filters/order.filter";
import { WarehouseService } from "../warehouse/warehouse.service";
import CreateOrderDto from "./dto/create-order.dto";
import { OrderStatus } from "./entities/order-status.enum";
import OrderQuantity from "./entities/order-quantity.entity";
import ProductQuantityDto from "../warehouse/dto/product-quantity.dto";
import ProductNotFoundException from "../product/exceptions/productNotFound.exception";
import ProductNotAvailableException from "../product/exceptions/productNotAvailable.exception";
import ProductAvailability from "../warehouse/entities/product-availability.entity";
import OrderNotEditableException from "./exceptions/productNotEditable.exception";
import UpdateOrderDto from "./dto/update-order.dto";
import { validate } from "class-validator";
import DeliveryOrderException from "./exceptions/delivery-order.exception";
import { User } from "../auth/entities/user.entity";
import { SortOrder } from "../../utils/sort-order.enum";
import Page from "../../utils/page";
import { OrderRepository } from "./repositories/order.repository";

@Injectable()
export class OrderService {
	private logger = new Logger(OrderService.name, { timestamp: true });

	constructor(
		@InjectRepository(Order) private orderRepository: OrderRepository,
		private warehouseService: WarehouseService
	) {
	}

	/**
	 * Ricerca un ordine tramite l'id
	 * @param idOrder
	 * @return
	 */
	async getOrder(idOrder: number): Promise<OrderDto> {
		const order = await this.orderRepository.findOne({
			where: { id: idOrder }
		});
		if (order) {
			return new OrderDto(order);
		}
		throw new OrderNotFoundException(idOrder);
	}

	/**
	 * Ritorna una lista di Ordini filtrata e ordinata
	 * @param filter  Pagina Richiesta (numero, dimensione, ordinamento) + Filtri per la class Order
	 * @return
	 */
	async getAll(filter: Partial<OrderFilter>): Promise<Page<OrderDto>> {
		const orderBy = { id: SortOrder.DESC };

		const where = {};
		const join: any = { alias: "order" };
		if (filter.warehouseName) {
			join.leftJoinAndSelect("order.warehouse", "warehouse");
			where["warehouse.name"] = filter.warehouseName;
		}
		if (filter.status) {
			where["status"] = filter.status;
		}

		const result = this.orderRepository.findAndCount({
			order: orderBy,
			skip: (filter.page - 1) * (filter.pageSize + 1),
			take: filter.pageSize,
			where
		});

		const query = await result;
		const dtoContent = query[0].map((o) => new OrderDto(o));

		return new Page(dtoContent, query[1], filter.page, filter.pageSize);
	}

	/**
	 * Crea un nuovo ordine
	 * @param order
	 * @return
	 */
	async createOrder(orderDto: CreateOrderDto, user: User): Promise<OrderDto> {
		const order = this.orderRepository.create({});
		const wh = await this.warehouseService.getNearestWareHouse(
			orderDto.address
		);
		order.warehouse = wh;
		order.address = wh.point;
		order.status = OrderStatus.CREATED;
		await this.updateProductOrderQuantity(order, orderDto.products);
		await this.orderRepository.save(order, { data: { user } });
		return new OrderDto(order);
	}

	async updateOrder(
		idOrder: number,
		orderDto: UpdateOrderDto,
		user: User
	): Promise<OrderDto> {
		const orderDB = await this.orderRepository.findOneBy({ id: idOrder });
		if (!orderDB) {
			this.logger.error(`Ordine con id ${idOrder} non trovato`);
			throw new OrderNotFoundException(idOrder);
		}
		if (orderDB.status != OrderStatus.CREATED) {
			this.logger.error(
				`Ordine con id ${idOrder} non può essere modificato in quanto è in stato '${orderDB.status}'`
			);
			throw new OrderNotEditableException(idOrder);
		}

		if (orderDto.address) {
			await validate(orderDto.address).then(async (errors) => {
				if (errors.length > 0) {
					this.logger.error(
						`Update dell'ordine con id ${idOrder} con indirizzo errato ${orderDto.address}`
					);
					throw new BadRequestException(errors);
				} else {
					const wh = await this.warehouseService.getNearestWareHouse(
						orderDto.address
					);
					orderDB.address = orderDto.address;
					orderDB.warehouse = wh;
				}
			});
		}

		if (orderDto.products) {
			await validate(orderDto.products).then(async (errors) => {
				if (errors.length > 0) {
					this.logger.error(
						`Update dell'ordine con id ${idOrder} con lista prodotti non valida ${orderDto.products}`
					);
					throw new BadRequestException(errors);
				} else {
					await this.updateProductOrderQuantity(
						orderDB,
						orderDto.products
					);
				}
			});
		}
		await this.orderRepository.save(orderDB, { data: { user } });

		return new OrderDto(orderDB);
	}

	async deleteOrder(idOrder: number, user: User): Promise<void> {
		const order = await this.orderRepository.findOneBy({ id: idOrder });
		if (!order) {
			this.logger.error(`Ordine con id ${idOrder} non trovato`);
			throw new OrderNotFoundException(idOrder);
		}
		if (order.status != OrderStatus.CREATED) {
			this.logger.error(
				`Ordine con id ${idOrder} non può essere modificato in quanto è in stato '${order.status}'`
			);
			throw new OrderNotEditableException(idOrder);
		}
		order.status = OrderStatus.DELETED;
		await this.orderRepository.save(order, { data: { user } });
	}

	/**
	 * Aggiorno la lista dei prodotto di un ordine controllando che siano disponibili nel magazzino di riferimento
	 * @param order
	 * @param productQuantityDtos Lista dei prodotti con le quantità associate
	 */
	private async updateProductOrderQuantity(
		order: Order,
		productQuantityDtos: ProductQuantityDto[]
	): Promise<void> {
		const productNames = productQuantityDtos.map((p) => p.name);

		//Prendo la lista dei prodotti disponibili nel magazzino selezionato
		const productAvailabilities =
			await this.warehouseService.areProductsAvailable(
				order.warehouse,
				order,
				productNames
			);
		const productAvailabilityMap = {};
		productAvailabilities.forEach((pa) => {
			productAvailabilityMap[pa.product.name] = pa;
		});

		const newProductOrderQuantityList: OrderQuantity[] = [];
		productQuantityDtos.forEach((pqd) => {
			const pa: ProductAvailability = productAvailabilityMap[pqd.name];
			if (pa == null) {
				this.logger.error(`Prodotto con nome ${pqd.name} non trovato`);
				throw new ProductNotFoundException(pqd.name);
			}
			const qta = pa.qta;
			if (qta < pqd.qta) {
				this.logger.error(
					`Il Prodotto con nome ${pqd.name} non è disponibile nel magazzino di riferimento ${order.warehouse.name}. Quantità ordinata: ${pqd.qta}/${qta}`
				);
				throw new ProductNotAvailableException(pqd.name);
			}
			const poq = new OrderQuantity({
				product: pa.product,
				order,
				qta: pqd.qta
			});
			newProductOrderQuantityList.push(poq);
		});
		order.products = newProductOrderQuantityList;
	}

	async calculateDelivery(orderIdList: number[]): Promise<OrderDto[]> {
		const orders = await this.orderRepository.findBy({
			id: In(orderIdList)
		});
		if (orders.length) {
			return [];
		}
		//controllo che tutti gli ordini siano associati allo stesso magazzino
		//viene anche verificato che tutti gli ordini siano nello stato corretto
		const wh = orders[0].warehouse;
		const sameWh = orders.every((o) => o.warehouse === wh);
		if (!sameWh) {
			this.logger.error(
				`Non tutti gli ordini sono associati allo stesso magazzino`
			);
			throw new DeliveryOrderException(
				"Non tutti gli ordini sono associati allo stesso magazzino"
			);
		}

		const anyWrongStatus = orders.some(
			(o) => o.status !== OrderStatus.CREATED
		);
		if (anyWrongStatus) {
			this.logger.error(
				`Non tutti gli ordini sono associati allo stesso magazzino`
			);
			throw new DeliveryOrderException(
				"Non tutti gli ordini sono associati allo stesso magazzino"
			);
		}
	}
}
