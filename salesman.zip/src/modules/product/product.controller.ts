import { Controller, Logger, UseGuards } from "@nestjs/common";
import { AuthGuard } from "@nestjs/passport";



@Controller('/api/v1/products')
@UseGuards(AuthGuard())
export class ProductController {
  private logger = new Logger('ProductController',{timestamp:true});
}