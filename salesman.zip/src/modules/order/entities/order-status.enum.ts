export enum OrderStatus {
  CREATED,
  SHIPPED,
  DELETED,
}
