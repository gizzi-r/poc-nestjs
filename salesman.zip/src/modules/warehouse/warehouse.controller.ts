import { Body, Controller, Get, Logger, Post, UseGuards } from "@nestjs/common";
import CreateWarehouseDto from "./dto/create-warehouse.dto";
import WarehouseDto from "./dto/warehouse.dto";
import { WarehouseService } from "./warehouse.service";
import {
	ApiBearerAuth,
	ApiBody,
	ApiOkResponse,
	ApiOperation,
	ApiResponse,
	ApiTags,
} from "@nestjs/swagger";
import { GetUser } from "../auth/decorators/get-user.decorator";
import { User } from "../auth/entities/user.entity";
import { Roles } from "../auth/decorators/roles.decorator";
import { Role } from "../auth/entities/roles";
import { AuthGuard } from "@nestjs/passport";
import { RolesGuard } from "../auth/guards/roles.guard";

@ApiTags("Warehouse")
@Controller("/api/v1/warehouses")
@ApiBearerAuth()
@UseGuards(AuthGuard(),RolesGuard)
export class WarehouseController {
	private logger = new Logger("WarehouseController", { timestamp: true });
	constructor(private warehouseService: WarehouseService) {}

	@ApiOperation({
		summary: "Ritorna la lista dei magazzini",
	})
	@ApiOkResponse({
		status: 200,
		description: "Lista dei magazzini",
		type: WarehouseDto,
		isArray: true,
	})
	@Roles(Role.ADMIN)
	@Get()
	getAll(): Promise<WarehouseDto[]> {
		const whList = this.warehouseService.getAll();
		return whList;
	}

	@Post()
	@ApiOperation({
		summary: "",
	})
	@ApiResponse({
		status: 201,
		description: "Warehouse successfully created.",
	})
	@ApiResponse({ status: 403, description: "Forbidden." })
	@ApiBody({
		type: CreateWarehouseDto,
		description: "Json structure for warehouse object",
	})
	@Roles(Role.ADMIN)
	addWarehouse(
		@Body() body: CreateWarehouseDto,
		@GetUser() user: User
	): Promise<WarehouseDto> {
		const wh = this.warehouseService.createWarehouse(body, user);
		return wh;
	}
}
