import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import Warehouse from '../entities/warehouse.entity';
import { OrderStatus } from "../../order/entities/order-status.enum";
import OrderQuantity from "../../order/entities/order-quantity.entity";

export class WarehouseRepository extends Repository<Warehouse> {
  constructor(
    @InjectRepository(Warehouse)
    private warehouseRepository: Repository<Warehouse>,
  ) {
    super(
        warehouseRepository.target,
        warehouseRepository.manager,
        warehouseRepository.queryRunner,
    );
  }

}
