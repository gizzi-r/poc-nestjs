import { Repository } from "typeorm";
import ProductAvailability from "../entities/product-availability.entity";
import { InjectRepository } from "@nestjs/typeorm";
import Warehouse from "../entities/warehouse.entity";

export class ProductAvailabilityRepository extends Repository<ProductAvailability>{
    constructor(
        @InjectRepository(ProductAvailability) private productAvailabilityRepository: Repository<ProductAvailability>
    ){
       super(productAvailabilityRepository.target,productAvailabilityRepository.manager,productAvailabilityRepository.queryRunner); 
    }

    async findByWarehouseAndProductNameIn(warehouse:Warehouse, productsName: string[]): Promise<ProductAvailability[]>{
       //Prendo la lista della disponibilità effettiva dei prodotti
        const productAvailabilityList = this.productAvailabilityRepository.createQueryBuilder("productAvailability")
        .leftJoinAndSelect('productAvailability.product','product')
        .where({warehouse})
        .andWhere('product.name in (:...productsName)',{productsName}).getMany();
        return productAvailabilityList;

          //   const {status,search} = filterDto;
  //   const query = this.tasksRepository.createQueryBuilder('task');

  //   query.where({user})

  //   if (status){
  //     query.andWhere('task.status = :status',{status})
  //   }
  //   if (search){
  //     query.andWhere('(task.title = :status OR task.description = :status)',{search})
  //   }
  //   const tasks = await query.getMany();

  //   return tasks;

    }
}