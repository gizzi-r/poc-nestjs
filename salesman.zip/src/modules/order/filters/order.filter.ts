import { GenericFilter } from "../../../utils/page-filter";


export default class OrderFilter extends GenericFilter {
    
    warehouseName: string
    status: string
}