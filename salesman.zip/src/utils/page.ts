import { number } from "joi";

export default class Page<T>{
    content: T[];
    totalElements: number;
    pageNum: number;
    pageSize: number;

    constructor( content : T[], totalElements: number, pageNumber: number, pageSize: number){
        this.content= content;
        this.totalElements= totalElements;
        this.pageNum = pageNumber;
        this.pageSize = pageSize;
    }
}