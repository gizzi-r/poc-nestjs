import { Injectable, Logger } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import Warehouse from "./entities/warehouse.entity";
import CreateWarehouseDto from "./dto/create-warehouse.dto";
import WarehouseDto from "./dto/warehouse.dto";
import Order from "../order/entities/order.entity";
import ProductAvailability from "./entities/product-availability.entity";
import { ProductAvailabilityRepository } from "./repositories/product-availability.repository";
import OrderQuantity from "../order/entities/order-quantity.entity";
import { OrderQuantityRepository } from "./repositories/order-quantity.repository";
import { OrderStatus } from "../order/entities/order-status.enum";
import Point from "src/utils/point";
import WarehouseNotFoundException from "./exceptions/warehouseNotFound.exception";
import WarehouseTooFarException from "./exceptions/warehouseTooFar.exception";
import { User } from "../auth/entities/user.entity";
import { WarehouseRepository } from "./repositories/warehouse.repository";

@Injectable()
export class WarehouseService {
	private logger = new Logger("WarehouseService", { timestamp: true });

	readonly MAX_WH_DISTANCE: number = 150000;

	constructor(
		@InjectRepository(Warehouse)
		private warehouseRepository: WarehouseRepository,
		private productAvailabilityRepository: ProductAvailabilityRepository,
		private orderQuantityRepository: OrderQuantityRepository
	) {
	}

	async getAll(): Promise<WarehouseDto[]> {
		const query = this.warehouseRepository.createQueryBuilder("warehouse");

		const whs = await query.getMany();

		return whs.map((wh) => new WarehouseDto(wh));
	}

	async createWarehouse(
		dto: CreateWarehouseDto,
		user: User
	): Promise<WarehouseDto> {
		const { name, point } = dto;
		const wh = this.warehouseRepository.create({
			name,
			point
		});
		await this.warehouseRepository.save(wh, { data: { user } });
		return new WarehouseDto({
			name: wh.name,
			point: wh.point
		});
	}

	public async getNearestWareHouse(point: Point): Promise<Warehouse | null> {
		const warehouseList = await this.warehouseRepository.find();
		let nearest: Warehouse | null = null;
		let nearestDistance: number = Number.MAX_VALUE;
		warehouseList.forEach((wh) => {
			const distance = wh.point.distance(point);
			if (nearestDistance == null || nearestDistance > distance) {
				nearest = wh;
				nearestDistance = distance;
			}
		});

		if (nearestDistance == null) {
			this.logger.error("Non sono stati definiti dei Magazzini");
			throw new WarehouseNotFoundException();
		}
		if (nearestDistance > this.MAX_WH_DISTANCE && nearest) {
			this.logger.error(
				`L'indirizzo ${point} si trova troppo distante (${nearestDistance} m) dal magazzino più vicino ${nearest}`
			);
			throw new WarehouseTooFarException(nearest, nearestDistance);
		}
		return nearest;
	}

	/**
	 * Dato un warehouse ed una lista di nomi prodotto verifico le disponibilità
	 *
	 * @param warehouse
	 * @param order
	 * @param products
	 * @return
	 */
	public async areProductsAvailable(
		warehouse: Warehouse,
		order: Order | null,
		products: string[]
	): Promise<ProductAvailability[]> {
		//Prendo la lista della disponibilità effettiva dei prodotti
		const productAvailabilityList = await this.productAvailabilityRepository.findByWarehouseAndProductNameIn(warehouse,products);

		//Prendo le quantità in pending per gli ordini non spediti
		let poq: OrderQuantity[];
		if (order == null) {
			poq = await this.orderQuantityRepository.findByOrderWarehouseAndOrderStatus(warehouse, OrderStatus.CREATED);
		} else {
			poq = await this.orderQuantityRepository.findByOrderWarehouseAndOrderStatusAndOrderIdNot(warehouse, OrderStatus.CREATED, order.id);
		}

		//Aggiorno le quantità disponibili nel magazzino
		const newProductAvailabilityList = productAvailabilityList.map(
			(productAvailability) => new ProductAvailability(productAvailability)
		);
		poq.forEach((orderQuantity) => {
			const q = newProductAvailabilityList.find(
				(pa) => pa.productId === orderQuantity.product.id
			);
			if (q) {
				q.qta -= orderQuantity.qta;
			}
		});

		return newProductAvailabilityList;
	}
}
