import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import Warehouse from '../entities/warehouse.entity';
import { OrderStatus } from "../../order/entities/order-status.enum";
import OrderQuantity from "../../order/entities/order-quantity.entity";

export class OrderQuantityRepository extends Repository<OrderQuantity> {
  constructor(
    @InjectRepository(OrderQuantity)
    private orderQuantityRepository: Repository<OrderQuantity>,
  ) {
    super(
      orderQuantityRepository.target,
      orderQuantityRepository.manager,
      orderQuantityRepository.queryRunner,
    );
  }

  findByOrderWarehouseAndOrderStatus(warehouse: Warehouse, status : OrderStatus): Promise<OrderQuantity[]>{
    const productAvailabilityList = this.orderQuantityRepository.createQueryBuilder("orderQuantity")
    .leftJoinAndSelect('orderQuantity.order','order')
    .leftJoinAndSelect('order.warehouse','warehouse')
    .where({warehouse})
    .andWhere('order.status = :status',{status}).getMany();
    return productAvailabilityList;
  }

  findByOrderWarehouseAndOrderStatusAndOrderIdNot(warehouse: Warehouse, status : OrderStatus, orderId: number): Promise<OrderQuantity[]>{
    const productAvailabilityList = this.orderQuantityRepository.createQueryBuilder("orderQuantity")
    .leftJoinAndSelect('orderQuantity.order','order')
    .leftJoinAndSelect('order.warehouse','warehouse')
    .where({order:{warehouse}})
    .andWhere('order.status = :status',{status})
    .andWhere('order.id != :orderId',{orderId})
    .getMany();
    return productAvailabilityList;
  }

}
