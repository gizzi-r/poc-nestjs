export enum SortOrder {
    ASC = 'ASC',
    DESC = 'DESC',
  }