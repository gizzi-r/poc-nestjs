import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Logger,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import OrderDto from './dto/order.dto';
import { OrderService } from './order.service';
import OrderFilter from './filters/order.filter';
import CreateOrderDto from './dto/create-order.dto';
import { GetUser } from '../auth/decorators/get-user.decorator';
import UpdateOrderDto from './dto/update-order.dto';
import { ApiNotFoundResponse, ApiOkResponse, ApiOperation, ApiProperty } from '@nestjs/swagger';
import { User } from '../auth/entities/user.entity';
import Page from "../../utils/page";

@Controller('/api/v1/orders')
@UseGuards(AuthGuard())
export class OrderController {
  private logger = new Logger('OrderController', { timestamp: true });

  constructor(private orderService: OrderService) {}

  @ApiOperation({
		summary: "Ricerca un ordine tramite id",
	})
  @ApiOkResponse({
    description: "Ordine Trovato",
		type: OrderDto,
  })
  @ApiNotFoundResponse({
    description: "Ordine non Trovato",
  })
  @Get('/:orderId')
  getOrder(@Param('orderId') orderId: number): Promise<OrderDto> {
    return this.orderService.getOrder(orderId);
  }

  @Get()
  getOrderList(@Query() filter: OrderFilter): Promise<Page<OrderDto>> {
    return this.orderService.getAll(filter);
  }

  @Post()
  @HttpCode(HttpStatus.CREATED)
  createOrder(@Body() orderDto: CreateOrderDto,@GetUser() user: User): Promise<OrderDto> {
    return this.orderService.createOrder(orderDto,user);
  }

  @Patch("/:orderId")
  updateOrder(@Param('orderId') orderId: number,@Body() orderDto: UpdateOrderDto,@GetUser() user: User): Promise<OrderDto> {
    return this.orderService.updateOrder(orderId,orderDto,user);
  }

  @Delete("/:orderId")
  @HttpCode(HttpStatus.NO_CONTENT)
  deleteOrder(@Param('orderId') orderId: number,@GetUser() user: User): Promise<void> {
    return this.orderService.deleteOrder(orderId,user);
  }

  @Post("/delivery")
  calculateDelivery(@Body() orderIdList: number[]): Promise<OrderDto[]> {
    return this.orderService.calculateDelivery(orderIdList);
  }


}
